-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2017 at 10:05 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `penjualanonline`
--
CREATE DATABASE IF NOT EXISTS `penjualanonline` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `penjualanonline`;

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `alamat` varchar(25) NOT NULL,
  `no_telp` char(15) NOT NULL,
  `kode` varchar(15) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `no_telp`, `kode`, `nama_barang`) VALUES
(1, 'faris', 'jl. laos', '08576873732', 'S10', 'sepatu'),
(2, 'icha', 'Jl.plamongan', '085876536478', 'h10', 'jilbab'),
(3, 'widhi', 'Jl.ngampel', '089465868794', 'motor vario', 'm10'),
(4, 'prilla', 'Jl. tlogosari', '08746636668', 'tas hermes', 't10'),
(5, 'latief', 'Jl ngaliyan', '08857537676', 'microfone', 'mic10');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
